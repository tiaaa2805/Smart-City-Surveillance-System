package green1;

import org.greenrobot.eventbus.Subscribe;

import java.util.Set;

public class GeneralDisplay {

    private final String displayName;
    private final Set<EnvironmentType> followedTypes;

    public GeneralDisplay(String displayName,
                          Set<EnvironmentType> followedTypes) {
        this.displayName = displayName;
        this.followedTypes = followedTypes;
    }

    @Subscribe
    public void onTemperatureEvent(TemperatureEvent event) {

        if (!followedTypes.contains(event.getEnvironmentType())) {
            return; // ignore this event
        }

        System.out.println(displayName + " received update: Sensor "
                + event.getSensorId()
                + " at " + event.getLocation()
                + " (" + event.getEnvironmentType() + ") = "
                + event.getValue() + " grd C");
    }
}