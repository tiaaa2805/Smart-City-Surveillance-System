package green1;

public enum EnvironmentType {
    CITY,
    FOREST
}