package green1;

import java.util.Set;
import org.greenrobot.eventbus.EventBus;

public class MainSensors {

    public static void main(String[] args) {

        EventBus eventBus = EventBus.getDefault();

        // Displays

GeneralDisplay d1 =
                new GeneralDisplay("Display1",
                        Set.of(EnvironmentType.CITY, EnvironmentType.FOREST));
        GeneralDisplay d2 =
                new GeneralDisplay("Display2",
                        Set.of(EnvironmentType.CITY));

        GeneralDisplay d3 =
                new GeneralDisplay("Display3",
                        Set.of(EnvironmentType.FOREST));

	   GeneralDisplay d4 =
                new GeneralDisplay("Display4",
                        Set.of(EnvironmentType.CITY));


        eventBus.register(d1);
        eventBus.register(d2);
        eventBus.register(d3);
	   eventBus.register(d4);


        // Sensors
        TemperatureSensor ts1 =
                new TemperatureSensor(eventBus, "TS001",
                        "Arad", EnvironmentType.CITY, 0);

        TemperatureSensor ts2 =
                new TemperatureSensor(eventBus, "TS002",
                        "Timisoara", EnvironmentType.CITY, 0);

	  TemperatureSensor ts3 =
                new TemperatureSensor(eventBus, "TS003",
                        "PadureaVerde", EnvironmentType.FOREST, 0);

        TemperatureSensor ts4 =
                new TemperatureSensor(eventBus, "TS004",
                        "Bazos", EnvironmentType.FOREST, 0);


        // Simulate
        ts1.setTemperatureValue(25);
        ts2.setTemperatureValue(10);
        ts3.setTemperatureValue(25);
        ts4.setTemperatureValue(10);

    }
}