package green1;

public class TemperatureEvent {
    private final String sensorId;
    private final String location;
    private final float value;
    private final EnvironmentType environmentType;

    public TemperatureEvent(String sensorId,
                            String location,
                            float value,
                            EnvironmentType environmentType) {
        this.sensorId = sensorId;
        this.location = location;
        this.value = value;
        this.environmentType = environmentType;
    }

    public String getSensorId() { return sensorId; }
    public String getLocation() { return location; }
    public float getValue() { return value; }
    public EnvironmentType getEnvironmentType() { return environmentType; }
}