package green1;

import org.greenrobot.eventbus.EventBus;


public class TemperatureSensor {
    private final EventBus eventBus;
    private final String id;
    private final String location;
    private final EnvironmentType environmentType;
    private float temperatureValue;

    public TemperatureSensor(EventBus eventBus,
                             String id,
                             String location,
                             EnvironmentType environmentType,
                             float temperatureValue) {
        this.eventBus = eventBus;
        this.id = id;
        this.location = location;
        this.environmentType = environmentType;
        this.temperatureValue = temperatureValue;
    }

    public void setTemperatureValue(float temperatureValue) {
        this.temperatureValue = temperatureValue;

        TemperatureEvent event =
                new TemperatureEvent(id, location, temperatureValue, environmentType);

        eventBus.post(event);
    }
}